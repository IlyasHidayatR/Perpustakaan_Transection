<?php return array (
  'anggota-livewire' => 'App\\Http\\Livewire\\AnggotaLivewire',
  'buku-livewire' => 'App\\Http\\Livewire\\BukuLivewire',
  'peminjaman-livewire' => 'App\\Http\\Livewire\\PeminjamanLivewire',
  'pengembalian-livewire' => 'App\\Http\\Livewire\\PengembalianLivewire',
  'petugas-livewire' => 'App\\Http\\Livewire\\PetugasLivewire',
  'rak-livewire' => 'App\\Http\\Livewire\\RakLivewire',
);