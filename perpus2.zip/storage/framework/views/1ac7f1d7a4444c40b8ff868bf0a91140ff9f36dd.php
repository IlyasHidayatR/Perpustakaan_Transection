<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('judul','Home'); ?>
<div class="flex flex-wrap">
    <div class="w-full p-6">
        <h1><b>Teknik Informatika</b></h1>
        <hr>
        <h2>Ilyas Hidayat Rusdy</h2>
        <h2>1915101021</h2>
        <h2>Ilmu Komputer 4A</h2>
        <br>
        <center><img src="<?php echo e(asset('gambar/buku.png')); ?>" style="height: 90px; width: 90px"></center>
        <p style="text-align: justify">
         Aplikasi ini adalah aplikasi sistem informasi perpustakaan. Maksud dari sistem informasi perpustakaan
         adalah sistem peminjaman buku perpustakaan. Aplikasi ini berfungsi sebagai penyimpanan data dari peminjaman
         buku dan juga sebagai penyimpanan informasi lainnya seperti anggota, petugas, dan buku.
        </p>
        <br>
        <b>Sistem Informasi ada pada laman tasks</b>
    </div>
</div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\perpus2\resources\views/dashboard.blade.php ENDPATH**/ ?>