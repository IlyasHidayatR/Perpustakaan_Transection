<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php $__env->startSection('title','Create'); ?>
<?php $__env->startSection('judul','Tambah Data'); ?>
<div class="flex flex-wrap">
        <div class="w-full p-6">
            <h1><b>Data Anime</b></h1>
            <hr>
            <h1><i><b>Input Data</b></i></h1>
            <form method="post"action="/getanime/{id_genre}">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="skor" class="form-label">Nama Anime: </label><br>
                    <input type="text" class="w-full bg-gray-200 text-black border border-gray-200 rounded py-3 px-4 mb-3" id="nama_anime" name="nama_anime" placeholder="Masukkan Judul" value="<?php echo e(old ('nama_anime')); ?>">
                </div>
                <div class="form-group">
                    <label for="skor" class="form-label">Genre Anime: </label><br>
                    <select class="w-full bg-gray-200 text-black border border-gray-200 rounded py-3 px-4 mb-3" style="width: 100" name="id_buku" id="id_buku" required>
                        <option disable value>Pilih Genre</option>
                        <?php $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bk->id_genre); ?>"><?php echo e($bk->nama_genre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="skor" class="form-label">Deskripsi: </label><br>
                    <textarea name="deskripsi" id="deskripsi" class="w-full bg-gray-200 text-black border border-gray-200 rounded py-3 px-4 mb-3" cols="30" rows="10" placeholder="Penjelasan"></textarea>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-9">
                        <button type="submit" name="submit" class="md:w-full bg-gray-900 text-white font-bold py-2 px-4 border-b-4 hover:border-b-2 border-gray-500 hover:border-gray-100 rounded-full" style="background-color:brown; color:white;">Submit</button> <br>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-9">
                        <button type="submit" class="md:w-full bg-gray-900 text-white font-bold py-2 px-4 border-b-4 hover:border-b-2 border-gray-500 hover:border-gray-100 rounded-full" style="background-color:blue"><a href="/anime" style="color:white">Kembali</a></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\perpus2\resources\views/anime/create.blade.php ENDPATH**/ ?>