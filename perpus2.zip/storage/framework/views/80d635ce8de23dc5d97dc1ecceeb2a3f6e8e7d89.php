<?php $__env->startSection('title','Data'); ?>
<?php $__env->startSection('judul','Tasks'); ?>
<?php $__env->startSection('page','/anggota'); ?>
<?php $__env->startSection('request','request'); ?>

<div class="flex flex-wrap">
    <div class="w-full p-6">
    <div class="bg-white">
        <nav class="flex flex-col sm:flex-row">
            <button class="text-gray-600 py-4 px-6 block hover:text-blue-500 focus:outline-none">
            <a href="<?php echo e(route('peminjaman')); ?>" :active="request()->routeIs('peminjaman')">Peminjaman</a>
            </button><button class="text-gray-600 py-4 px-6 block hover:text-blue-500 focus:outline-none">
            <a href="<?php echo e(route('pengembalian')); ?>" :active="request()->routeIs('pengembalian')">Pengembalian</a>
            </button><button class="text-gray-600 py-4 px-6 block hover:text-blue-500 focus:outline-none text-blue-500 border-b-2 font-medium border-blue-500">
            <a href="<?php echo e(route('anggota')); ?>" :active="request()->routeIs('anggota')">Anggota</a>
            </button><button class="text-gray-600 py-4 px-6 block hover:text-blue-500 focus:outline-none">
            <a href="<?php echo e(route('petugas')); ?>" :active="request()->routeIs('petugas')">Petugas</a>
            </button><button class="text-gray-600 py-4 px-6 block hover:text-blue-500 focus:outline-none">
            <a href="<?php echo e(route('buku')); ?>" :active="request()->routeIs('buku')">Buku</a>
            </button><button class="text-gray-600 py-4 px-6 block hover:text-blue-500 focus:outline-none">
            <a href="<?php echo e(route('rak')); ?>" :active="request()->routeIs('rak')">Rak</a>
            </button>
        </nav>
    </div>
    <hr>
    <h2><b>Daftar Anggota</b></h2>
            <hr>
            <button wire:click="create()" class="box row-span-2 overflow-hidden grid-cols-1 grid-rows-2 gap-2" style="background-color:blue; color:white">Tambah Data</button>
            <?php if($isModal): ?>
                    <?php echo $__env->make('livewire.createanggota', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <button wire:click="export" class="box row-span-2 overflow-hidden grid-cols-1 grid-rows-2 gap-2" style="background-color:brown; color:white">Export</button>
            <button onclick="openModal(true)">
                <a class="box row-span-2 overflow-hidden grid-cols-1 grid-rows-2 gap-2" style="background-color:green; color:white">Import</a>
            </button>
            <form wire:submit.prevent="submit">
            <?php echo csrf_field(); ?>
            <!-- overlay -->
            <div id="modal_overlay" class="hidden absolute inset-0 bg-black bg-opacity-30 h-screen w-full flex justify-center items-start md:items-center pt-10 md:pt-0">

                <!-- modal -->
                <div id="modal" class="pacity-0 transform -translate-y-full scale-150  relative w-10/12 md:w-1/2 h-1/2 md:h-3/4 bg-white rounded shadow-lg transition-opacity transition-transform duration-300">

                    
                    <!-- header -->
                    <div class="px-4 py-3 border-b border-gray-200">
                        <h2 class="text-xl font-semibold text-gray-600">Upload File</h2>
                    </div>

                    <!-- body -->
                        <div class="w-full p-3">
                            <div class="form-group">
                            <label for="file">Masukkan file excel:</label>
                            <br>
                            <input type="file" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  wire:model="file" required>
                            </div>
                        </div>

                        <!-- footer -->
                        <div class="absolute bottom-0 left-0 px-4 py-3 border-t border-gray-200 w-full flex justify-end items-center gap-3">
                        <div class="form-group">
                        <button type="submit" class="bg-green-500 hover:bg-green-600 px-4 py-2 rounded text-white focus:outline-none">Save</button>
                        </div>
                        <button onclick="openModal(false)" class="bg-red-500 hover:bg-red-600 px-4 py-2 rounded text-white focus:outline-none">
                            Close
                        </button>
                    </div>
                </div>

            </div>

            <script>
                const modal_overlay = document.querySelector('#modal_overlay');
                const modal = document.querySelector('#modal');

                function openModal (value){
                const modalCl = modal.classList
                const overlayCl = modal_overlay

                if(value){
                overlayCl.classList.remove('hidden')
                setTimeout(() => {
                    modalCl.remove('opacity-0')
                    modalCl.remove('-translate-y-full')
                    modalCl.remove('scale-150')
                }, 100);
                } else {
                modalCl.add('-translate-y-full')
                setTimeout(() => {
                    modalCl.add('opacity-0')
                    modalCl.add('scale-150')
                }, 100);
                setTimeout(() => overlayCl.classList.add('hidden'), 300);
                    }
                }
                openModal(false)
            </script>
            </form>
            <?php if(session('message')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <table class="bg-white text-gray-900 w-full shadow-none">
                <thead>
                    <tr>
                    <th class="bg-blue-700 text-white p-2">No.</th>
                    <th class="bg-blue-700 text-white p-2">Kode Anggota</th>
                    <th class="bg-blue-700 text-white p-2">Nama Anggota</th>
                    <th class="bg-blue-700 text-white p-2">Jenis Kelamin</th>
                    <th class="bg-blue-700 text-white p-2">Jurusan</th>
                    <th class="bg-blue-700 text-white p-2">Telepon</th>
                    <th class="bg-blue-700 text-white p-2">Alamat</th>
                    <th class="bg-blue-700 text-white p-2">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $anggota1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="bg-blue-100 text-blue-900">
                <!-- $loop->iteration -->
                    <th class="p-2"><?php echo e($loop->iteration); ?>.</th>
                    <th class="p-2"><?php echo e($ag->kode_anggota); ?></th>
                    <th class="p-2"><?php echo e($ag->nama_anggota); ?></th>
                    <th class="p-2"><?php echo e($ag->jk_anggota); ?></th>
                    <th class="p-2"><?php echo e($ag->jurusan_anggota); ?></th>
                    <th class="p-2"><?php echo e($ag->no_telp_anggota); ?></th>
                    <th class="p-2"><?php echo e($ag->alamat_anggota); ?></th>
                    <th class="p-2">
                        <button wire:click="show(<?php echo e($ag->id_anggota); ?>)" class="border" style="background-color:aqua; color:white">detail</button>
                        <?php if($isModal1): ?>
                            <?php echo $__env->make('livewire.detailanggota', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                        <button wire:click="edit(<?php echo e($ag->id_anggota); ?>)" class="border" style="background-color:green; color:white">edit</button>
                        <button wire:click="delete(<?php echo e($ag->id_anggota); ?>)" class="badge badge-danger inline border" style="background-color:red; color:white">delete</button>
                    </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <th class="p-2 text-center" colspan="S">Tidak ada data</th>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
            <div class="inline-flex mt-2 xs:mt-0">
                <nav class="text-sm bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-4 rounded-l inline">
                    <?php echo e($anggota1->links()); ?>

                </nav>
                <?php echo \Livewire\Livewire::scripts(); ?>

                <?php echo \Livewire\Livewire::styles(); ?>

            </div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\perpus2\resources\views/livewire/anggota.blade.php ENDPATH**/ ?>