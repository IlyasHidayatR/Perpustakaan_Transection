require('./bootstrap');

require('alpinejs');
